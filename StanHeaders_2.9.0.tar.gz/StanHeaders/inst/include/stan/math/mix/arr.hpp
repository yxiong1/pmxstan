#ifndef STAN_MATH_MIX_ARR_HPP
#define STAN_MATH_MIX_ARR_HPP

#endif
